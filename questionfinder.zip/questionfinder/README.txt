Question finder module for Moodle (http://moodle.org/)
Copyright (C) 2020 Tobias Kutzner 
(Moodle Moot DACH 2019: 
Improve questionbank with better search options for question Tobias Kutzner, Katja Neubehler, Gerhard Schwed, Pedro Rojas)

Based on the question search module Copyright  (C) 2013 by Ray Morris. 
Extends the Moodle question bank to find text, and dates of creation or modification in questions via text search.

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details:
http://www.gnu.org/copyleft/gpl.html

Project Page:
* https://github.com/eLearnTK/questionfinder

Installation:
* http://docs.moodle.org/20/en/Installing_contributed_modules_or_plugins

Issue tracker:
* https://github.com/eLearnTK/questionfinder/issues
